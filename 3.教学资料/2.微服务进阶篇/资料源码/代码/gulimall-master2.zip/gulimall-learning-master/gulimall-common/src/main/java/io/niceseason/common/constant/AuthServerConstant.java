package io.niceseason.common.constant;

public class AuthServerConstant {
    public static final String SMS_CODE_CACHE_PREFIX = "sms:code:";
    public static final String LOGIN_USER = "loginUser";
}
