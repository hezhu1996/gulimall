package io.niceseason.common.group;

public interface UpdateGroup {
}
