package io.niceseason.gulimall.auto;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimallAutoServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
