package io.niceseason.gulimall.auto.vo;

import lombok.Data;

@Data
public class UserLoginVo {

    private String loginAccount;
    private String password;
}
