package io.niceseason.gulimall.order.constant;

public class OrderConstant {
    public static final String USER_ORDER_TOKEN_PREFIX = "order:token";
}
