package io.niceseason.gulimall.member.vo;

import lombok.Data;


@Data
public class MemberRegisterVo {
    private String userName;

    private String password;

    private String phone;
}
