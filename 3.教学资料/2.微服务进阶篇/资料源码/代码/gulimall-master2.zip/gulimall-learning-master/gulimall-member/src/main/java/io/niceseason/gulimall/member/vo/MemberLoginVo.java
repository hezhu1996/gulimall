package io.niceseason.gulimall.member.vo;

import lombok.Data;

@Data
public class MemberLoginVo {
    private String loginAccount;
    private String password;
}
