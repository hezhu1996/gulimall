package io.niceseason.gulimall.product.vo;

import lombok.Data;

/**
 * @Description:
 * @Created: with IntelliJ IDEA.
 * @author: 夏沫止水
 * @createTime: 2020-06-23 18:59
 **/

@Data
public class AttrValueWithSkuIdVo {

    private String attrValue;

    private String skuIds;

}
